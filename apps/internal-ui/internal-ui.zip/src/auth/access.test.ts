import { describe, expect, it } from "vitest";

import type { SessionUser } from "../types";
import { canAccess, defaultRoute } from "./access";

const baseUser: Omit<SessionUser, "role" | "capabilities" | "accessScopes"> = {
  id: 1,
  email: "employee@example.test",
  fullName: "Employee",
  positionTitle: "Specialist",
  organization: "example",
  organizationName: "Example",
  department: null,
  mustChangePassword: false,
  totpRequired: false,
  totpEnabled: false,
};

function userWith(
  capabilities: string[],
  departmentCode: string | null = null,
): SessionUser {
  return {
    ...baseUser,
    role: "EMPLOYEE",
    capabilities,
    accessScopes: [
      {
        scopeType: departmentCode ? "DEPARTMENT" : "ORGANIZATION",
        departmentId: departmentCode ? 10 : null,
        departmentCode,
        capabilities,
      },
    ],
  };
}

describe("effective access navigation", () => {
  it("uses organization capabilities instead of the system role", () => {
    const user = userWith(["company.view", "employees.view", "products.view"]);
    expect(canAccess(user, "command")).toBe(true);
    expect(canAccess(user, "employees")).toBe(true);
    expect(canAccess(user, "products")).toBe(true);
    expect(canAccess(user, "integrations")).toBe(false);
    expect(defaultRoute(user)).toBe("command");
  });

  it("keeps sales and support department scopes isolated", () => {
    const capabilities = ["conversations.view", "sales.view", "customers.view"];
    const sales = userWith(capabilities, "sales");
    const support = userWith(["conversations.view", "support.view"], "support");

    expect(canAccess(sales, "salesDialogs")).toBe(true);
    expect(canAccess(sales, "supportDialogs")).toBe(false);
    expect(canAccess(support, "supportDialogs")).toBe(true);
    expect(canAccess(support, "salesDialogs")).toBe(false);
  });

  it("combines multiple department assignments", () => {
    const user = userWith([], "sales");
    user.capabilities = ["conversations.view"];
    user.accessScopes = [
      { scopeType: "DEPARTMENT", departmentId: 10, departmentCode: "sales", capabilities: ["conversations.view"] },
      { scopeType: "DEPARTMENT", departmentId: 20, departmentCode: "support", capabilities: ["conversations.view"] },
    ];
    expect(canAccess(user, "salesDialogs")).toBe(true);
    expect(canAccess(user, "supportDialogs")).toBe(true);
    expect(defaultRoute(user)).toBe("salesDialogs");
  });

  it("falls back to self-service profile when no work capability is assigned", () => {
    const user = userWith([]);
    expect(canAccess(user, "profile")).toBe(true);
    expect(defaultRoute(user)).toBe("profile");
  });
});
